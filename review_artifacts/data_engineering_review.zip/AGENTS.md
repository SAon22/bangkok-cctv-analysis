# Repository instructions for Codex

These instructions apply throughout this repository.

## Read before changing substantial work

- Read [PROJECT_CONTEXT.md](PROJECT_CONTEXT.md) and
  [docs/data_dictionary.md](docs/data_dictionary.md) before substantial changes.
- Inspect relevant source, tests, configuration, and local artifacts. Historical
  notes and saved notebook outputs are evidence of earlier runs, not a substitute
  for checking the current implementation.
- Follow existing conventions. Keep changes scoped to the requested task and
  avoid modifying unrelated modules or another teammate's work.

## Implementation conventions

- Use Python 3.11 or newer, consistent with `pyproject.toml`.
- Write modular, readable, testable code. Use type hints and logging where useful.
- Resolve paths against the project root with `pathlib`. Store portable relative
  paths in datasets; do not hard-code a developer's filesystem location.
- Prefer Parquet for structured intermediate and processed tables. Use JSON for
  concise machine-readable summaries and provenance.
- Reuse established dependencies. Add dependencies only when necessary and
  explain why; do not introduce a framework for a small task.
- Never modify raw datasets, original images, or source metadata. Write derived
  artifacts to the agreed interim/processed locations.
- Reuse existing manifests and contracts; do not duplicate engineering logic in
  notebooks, analysis, or dashboard modules.
- Preserve camera IDs as strings, including leading zeros. Follow the documented
  timestamp, join, missing-data, and primary-key conventions.
- Do not change existing production schemas without explicit approval. A
  PROPOSED contract is a design for discussion, not an implemented interface.

## Team boundaries

| Responsibility | Owned paths |
| --- | --- |
| Engineering | `src/bangkok_cctv/engineering/` |
| Data Science: external sources and analysis | `src/bangkok_cctv/scraping/`, `src/bangkok_cctv/analysis/` |
| Dashboard and integration UI | `src/bangkok_cctv/dashboard/` |
| Shared coordination | Configuration, tests, notebooks, documentation, presentation |

Coordinate cross-module contract changes and respect these responsibilities.
Ownership does not authorize unrelated edits or unrequested features.

## Evidence and validation

- Do not invent analytical results. State which input, query, test, or executed
  notebook supports a finding; distinguish fresh checks from saved outputs.
- Image availability and visible vehicles per snapshot are not traffic volume,
  unique vehicles, or continuous traffic flow.
- Run relevant tests after changes. The project uses pytest with `src` on its
  import path: `python -m pytest -q`. Run configured lint checks when applicable
  and available; do not claim checks that were not run.
- Exercise real behavior where appropriate. Import-only scaffold tests do not
  establish that pipelines, models, or dashboard features work.
- Preserve existing files and user changes. Never regenerate or overwrite data
  artifacts just to update documentation.
- Update the context and dictionary when approved data contracts or major
  milestones change. Record unresolved assumptions, limitations, and integration
  dependencies explicitly.
