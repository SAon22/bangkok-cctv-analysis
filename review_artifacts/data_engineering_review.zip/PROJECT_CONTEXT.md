# Bangkok CCTV Image Analysis: project context

Last inspected: **November 15, 2026**. Submission deadline: **December 6, 2026**
(user-provided). This document describes the inspected local repository, including
ignored local artifacts. It does not imply those artifacts are committed or
available in a fresh checkout.

## Objectives and academic scope

This is a university Data Science and Data Engineering project. The README
describes the intended progression from Bangkok CCTV images to structured traffic
observations, approved external data collected through scraping, temporal/spatial
analysis, and an interactive Streamlit dashboard. Reproducible engineering,
validated observations, documented limitations, and a final presentation support
that objective.

The detailed course rubric, mandatory external sources, marking criteria, exact
submission time/timezone, and required deliverable formats are not present in the
inspected documentation. Confirm them with the course specification; do not
invent requirements. Vehicle counts per snapshot must not be presented as
continuous traffic flow.

## Team of three

| Role from README | Responsibilities | Paths |
| --- | --- | --- |
| Developer 1 / Engineering | Ingestion, manifest, future detection, preprocessing, validation | `src/bangkok_cctv/engineering/` |
| Developer 2 / Data Science | External-source definitions/collection, temporal and spatial analysis | `src/bangkok_cctv/scraping/`, `src/bangkok_cctv/analysis/` |
| Developer 3 / Dashboard | Dashboard, UI integration | `src/bangkok_cctv/dashboard/` |
| Shared | Contracts, configuration, tests, notebooks, documentation, presentation | Cross-team coordination |

Personal names and individual task assignments beyond these roles are unrecorded.

## Technology stack

- Python >=3.11; setuptools package using the `src/` layout.
- Implemented manifest/EDA: pandas, PyArrow/Parquet, Pillow, matplotlib,
  Jupyter/IPython. JSON reports accompany structured outputs.
- Declared in `pyproject.toml`: numpy, OpenCV, ultralytics, requests,
  BeautifulSoup, scipy, scikit-learn, Streamlit, Plotly, PyYAML.
  A declared dependency is not evidence that its feature is implemented or that
  model weights exist.
- Development extras: pytest, Ruff, Jupyter.
- Test configuration uses `tests/` and adds `src/` to the import path.
  Ruff targets Python 3.11 with an 88-character line length.
- `configs/config.yaml` is a scaffold; automatic config/environment loading is
  not implemented.

## Dataset and current evidence

Read-only checks in this documentation task loaded the actual CSV and Parquet,
inspected report structures and source code, recomputed timestamp/key statistics
from the saved manifest, and inspected notebook outputs. They did not rebuild
datasets, rerun the notebook, or decode every raw image.

| Characteristic | Verified evidence |
| --- | --- |
| Camera metadata | `data/raw/cctv_info.csv`: 100 rows, 9 columns |
| Image manifest | `data/interim/image_manifest.parquet`: 61,319 rows, 12 columns, 100 camera IDs |
| Image layout | Local extracted root is `data/raw/cctv_images/cctv_images/<camera_id>/`; the builder recursively scans `data/raw/cctv_images/` |
| Timestamp range | 2026-08-25 06:00:00 through 2026-08-31 21:01:19 |
| Dates | Seven: August 25-31, 2026 |
| Sampling | Median consecutive interval is 600 seconds per camera in the saved manifest summary |
| Counts per camera | 604-631 images |
| Keys and joins | No repeated image paths or camera/timestamp pairs; every manifest row matched CSV metadata |
| Timestamps | No invalid/missing values in the current manifest; timezone-naive, parsed from filename suffix |
| CSV missing values | `location_en`: 1; `location_detail_en`: 2; other CSV columns: 0 |
| Repeated metadata nulls in manifest | `location_en`: 614 rows; `location_detail_en`: 1,228 rows |
| Sampling gaps | Recomputed from manifest: 671 intervals >30 minutes; 71 within a date and 600 crossing dates |

Current timestamps are filename clock values, not verified UTC instants or
verified capture times. Image count means available files, not detected vehicles.

### Daily availability from the saved manifest summary

| Date | Images |
| --- | ---: |
| 2026-08-25 | 8,937 |
| 2026-08-26 | 8,953 |
| 2026-08-27 | 7,438 |
| 2026-08-28 | 9,015 |
| 2026-08-29 | 8,964 |
| 2026-08-30 | 9,002 |
| 2026-08-31 | 9,010 |

## Repository architecture

| Location | Current purpose and status |
| --- | --- |
| `data/raw/cctv_images/`, `data/raw/cctv_info.csv` | Local immutable inputs, ignored by Git |
| `data/raw/cctv/` | Legacy scaffold location, still referenced in configuration |
| `data/raw/external/` | External-input location; only .gitkeep found |
| `data/interim/` | Existing validation report, image manifest, manifest summary; ignored outputs |
| `data/processed/` | Future curated output location; only .gitkeep found |
| `src/bangkok_cctv/engineering/image_manifest.py` | Implemented filename parsing, metadata joins, manifest build/save and summaries |
| `src/bangkok_cctv/engineering/vehicle_detector.py` | Implemented reusable experimental YOLO detector; see Step 4 update |
| Other `engineering/` workflow modules | Image loader, preprocessing, validation and full orchestration still raise NotImplementedError |
| `src/bangkok_cctv/scraping/` | Source definitions, collection and orchestration remain placeholders |
| `src/bangkok_cctv/analysis/` | Packaged EDA, temporal/spatial analysis and insights remain placeholders |
| `src/bangkok_cctv/dashboard/` | Landing-page implementation; loader, charts and pages remain placeholders |
| `scripts/explore_dataset.py` | Implemented extracted-image inspection and validation report |
| `scripts/build_image_manifest.py` | Implemented CLI with project-root discovery and optional --project-root |
| `scripts/run_engineering.py`, `run_scraping.py`, `run_analysis.py` | Call placeholder workflows; not usable end-to-end pipelines |
| `notebooks/01_data_exploration.ipynb` | Implemented six-section visual EDA over existing artifacts |
| `tests/` | 13 manifest behavior cases and 12 scaffold import cases |
| `models/`, `presentation/` | Local weights location and presentation scaffold; no deliverable evidenced |
| `docs/` | Architecture notes and existing/proposed data contracts |

## Checkpoints: historical reports versus inspected state

| Checkpoint | Historical report | Current repository verification |
| --- | --- | --- |
| Step 1: validation | 100 cameras, 61,319 images; script and report produced | Script exists and supports extracted folders. Saved dataset_report.json is now **complete**, errors=[], 100 cameras, 61,319 images, no missing cameras/count mismatches; five recorded readable samples |
| Step 2: manifest | Module, CLI, Parquet and summary produced; 25 tests passed | All four artifacts exist. Actual Parquet schema and values were inspected. **25 tests passed again** during this task |
| Step 3: visual EDA | Eight figures, 300 sampled images, 671 gaps >30 minutes | Notebook contains six sections, 10 executed code cells, eight embedded PNG figures and no saved cell errors. Its saved outputs report 300 samples, zero unreadable samples and three resolution/format combinations; gap totals were independently recomputed from the manifest |

Earlier incomplete validation reports caused by missing Pillow are historical;
the current report says complete. Notebook sample-readability findings are saved
execution evidence, not a fresh all-image validation. Recorded sample resolutions
are 352x288 (296 JPEG), 348x261 (3 JPEG), and 400x266 (1 PNG).

Current test verification command (using existing dependencies, no installation):
`python -B -m pytest -q -p no:cacheprovider`, with bytecode generation and
third-party plugin autoload disabled. Result: **25 passed**. The manifest test
file is currently untracked; a successful local test run does not establish
that every teammate has it.

## Milestones and remaining work

1. **Completed locally:** dataset validation, portable image manifest, visual
   availability/quality EDA, and the documentation baseline in this task.
2. **Next integration milestone:** agree on the PROPOSED v1 contracts in the
   dictionary, vehicle taxonomy, evaluation protocol, and timezone evidence.
   These contracts have not been implemented or approved.
3. **Engineering remaining:** annotate a small evaluation set; select/evaluate
   a detector and weights; implement inference, failure records, preprocessing,
   validation, and reproducible orchestration after the contract is approved.
4. **Data Science remaining:** approve external sources and provenance; implement
   collection, temporal/spatial matching and coverage-aware analysis; evaluate
   snapshot counts without claiming unique traffic throughput.
5. **Dashboard remaining:** implement processed-data loading, availability/error
   indicators, temporal/spatial views and integration against agreed outputs.
6. **Shared remaining:** integration tests, evaluation evidence, reconcile legacy
   README/configuration/architecture descriptions, final report/presentation and
   submission preparation by December 6. Intermediate dates are not agreed.

## Integration dependencies

- Engineering publishes stable image keys, camera IDs, timestamp semantics,
  model-run provenance and explicit inference status; Data Science and Dashboard
  must agree on contract versions before consuming new outputs.
- The manifest joins CSV metadata many-to-one. Duplicate/missing metadata IDs
  are rejected; unmatched images are retained and flagged.
- Detection needs accessible local images and separately supplied weights.
  An experimental detector exists; production outputs and the full pipeline remain unimplemented.
- External integration needs documented source licensing/access, geographic and
  temporal resolution, timezones, join tolerances and provenance. Camera IP
  addresses are source metadata, not geographic keys or evidence of an API.
- Dashboard pages depend on curated outputs and coverage/status semantics.
  Do not use zero as a substitute for missing/failed inference.
- Local raw/interim artifacts are ignored by Git, so a fresh checkout needs a
  documented acquisition/access process. Do not commit datasets to resolve that.
- `AGENTS.md` and `PROJECT_CONTEXT.md` are also currently ignored by existing
  .gitignore rules. They exist locally but require an explicit Git-policy
  decision (or deliberate force-add) to share. This task does not edit ignore
  rules or stage files.

## Limitations, risks and unresolved decisions

- README and docs/architecture.md still describe the initial scaffold and their
  universal placeholder claims are stale. Config raw_cctv points to
  data/raw/cctv rather than the implemented manifest input. These files are
  intentionally preserved by this documentation-only task.
- Snapshot availability, median sampling and image decoding do not establish
  detector accuracy, unique vehicles or traffic flow. One observed week limits
  generalization, and gaps can bias comparisons.
- Image resolutions are small and vary in the sample. Viewpoint, blur, occlusion,
  lighting, overlays, and unsampled-image readability need assessment.
- Filename time provenance, timezone and camera clock accuracy are unverified.
  UTC conversion is a proposed future convention, not existing behavior.
- Coordinate plausibility screening is not CRS/geolocation verification.
  English location labels have missing values and are not guaranteed translations.
- Existing schemas have no explicit schema_version or immutable image content
  identifier. Relative image_path is the current observed unique key; renaming
  or moving files changes it.
- Twelve scaffold tests only check imports; newer tests cover manifest and mocked
  feasibility behavior. No automated real-model evaluation or scraping/dashboard
  integration tests exist. The parser test's location text currently contains literal
  question marks, so it does not demonstrate Thai filename handling.
- Confirm the course rubric, team names, source permissions, timezone evidence,
  model/class mapping, contract approval and sharing policy. No analytical
  results should be claimed for features that still raise NotImplementedError.

## Step 4 completion update (November 15, 2026)

This update supersedes the earlier detector-placeholder and test-count statements
above; Steps 1-3 remain the previously verified checkpoints.

- Implemented reusable local-weight inference in
  `src/bangkok_cctv/engineering/vehicle_detector.py`; preserved the existing
  `detect_vehicles(image_path, weights_path) -> dict[str, int]` API.
- Added deterministic, camera-balanced camera/date/time-band sampling and
  failure-aware artifact generation in `engineering/yolo_feasibility.py`,
  exposed through `scripts/test_yolo_feasibility.py`. Sampling-only mode works
  without model weights or importing Ultralytics.
- Saved the sampling-only run under
  `data/interim/yolo_feasibility_sampling_only/` and the actual CPU run under
  `data/interim/yolo_feasibility/`. Each has sample_manifest.parquet,
  detections.parquet, summary.json and an annotated_images directory.
- Verified real YOLOv8 nano inference at confidence 0.25 on 100 images covering
  100 cameras, seven dates and all three clock bands: 100 successful images,
  14 successful zeros, 0 failed images, 0 annotation errors and 100 annotations.
  The 444 predictions comprise 318 cars, 12 motorcycles, 75 buses and 39 trucks.
- Rechecked saved artifact traceability, count consistency, manifest/weight
  checksums, sample reproducibility and annotation file existence. The current
  public detector API also passed a real one-image smoke check.
- Final existing/new unit-test result: **53 passed** (13 manifest behavior cases,
  28 feasibility/detector cases, 12 scaffold import cases). Unit inference is
  mocked; no weights are downloaded by tests.
- The explicitly downloaded local model is `models/yolov8n.pt`. The selected
  environment now has CPU PyTorch, torchvision and Ultralytics; pyproject.toml
  declarations and dependency versions were not edited.
- The experimental schema is documented separately as
  **feasibility-1.0.0** in [the dictionary](docs/data_dictionary.md). It does not
  implement the proposed production schemas or change existing manifest fields.
  Downstream contract approval is still needed.
- [Step 4 usage/results](docs/step4_yolo_feasibility.md) records executed commands,
  versions, sample limitations, runtime measurements and final verification.

Remaining: manual inspection and labelled evaluation, production taxonomy/timezone
agreement, failure/retry and full-pipeline design, approved external integration,
packaged analysis and dashboard implementation. These pretrained outputs are
predictions, not ground truth; no precision, recall, accuracy or traffic-flow
claim is supported. Raw inputs and original manifest remain unchanged.

## Step 4.5B ROI-aware evaluation (November 16, 2026)

The reviewed scope CSV passed (8/8 reviewed, five full and three ROI scopes).
Implemented pure matching/conversion helpers in engineering/detection_evaluation.py
and scripts/evaluate_yolo.py, reading only saved Step 4.5A predictions.
All 96 tests passed. No inference, training, label edits or input changes occurred.

Within the reviewed scopes, 76 GT boxes (42 car, 34 motorcycle) were included.
Baseline: TP=18, FP=7, FN=58, precision=.720000, recall=.236842, F1=.356436,
count MAE=6.375. Low-confidence: TP=29, FP=104, FN=47, precision=.218045,
recall=.381579, F1=.277512, count MAE=13.625. Bus/truck GT support is zero
after ROI filtering, so their recall is undefined. These are hand-picked
diagnostic-region results, not representative holdout or traffic-flow metrics.

Outputs: data/interim/yolo_ground_truth/evaluation/. Rules, data contracts and
limitations: [Step 4.5B evaluation](docs/step45b_roi_evaluation.md).
The reviewed CSV is authoritative; local review notes retain stale pending text.

## Step 5 checkpointed detection update (November 16, 2026)

Implemented the existing engineering pipeline scaffold and run_engineering CLI,
with atomic paired-Parquet checkpoints, compatible resume, OS single-writer
locking, immutable run provenance and fixed YOLOv8n baseline settings. The
legacy config-path API remains usable; configs/config.yaml points to the existing
models/yolov8n.pt and explicit manifest/output/chunk settings.

All 114 tests passed. A separate smoke run processed exactly 20 images from 20
cameras and seven dates in two invocations (10, then 10 after resume): 20 successful
image records, three successful zeros, no errors, 98 detections (car 60,
motorcycle 3, bus 23, truck 12). Earlier checkpoint files remained byte-identical;
a completed resume performed no model loading or inference.

Outputs: data/interim/detection_pipeline_smoke/. Smoke manifest:
data/interim/detection_pipeline_smoke_manifest.parquet. Source manifest, raw data
and earlier ground-truth/evaluation/diagnostic artifacts were preserved.
[Step 5 documentation](docs/step5_detection_pipeline.md) contains schemas, commands,
recovery guarantees and limitations. Steady smoke image processing extrapolates
to roughly 38 minutes for the full dataset plus checkpoint/setup overhead; this
is an estimate, not a measured full run. Full-dataset inference was not started.
Cleaning (Step 6) and integration/data-contract approval (Step 7) remain separate.

## Step 5 full-dataset completion

Full baseline inference is complete, superseding the earlier smoke-only state.
Output: data/interim/detection_runs/yolov8n_baseline_full_01/.
The unchanged YOLOv8n CPU baseline processed all 61,319 images from 100 cameras
in one invocation: 61,319 successes, zero errors and 10,488 successful zeros.
There are 274,096 predictions: car 208,919, motorcycle 12,592, bus 29,161,
truck 23,424. Actual process wall time was 3,691.060 seconds (1 h 1 min 31 s).

All 614 checkpoints finalized; no pending chunks, missing manifest images or
duplicate image/detection keys were found. Final checks validated checksums,
schemas, source indices, references, counts and unchanged camera IDs/timestamps.
All 215 protected artifacts/input/code files stayed unchanged. No interruption
or resume was required during this full run. An execution report and typed empty
failed-image table accompany the raw checkpoint outputs.

No Step 6 cleaning or Step 7 integration was started. Predictions retain the
known model limitations and do not establish traffic flow or ground truth.


## Step 6 completion: detection validation

Implemented `engineering/detection_validation.py` and `scripts/validate_detections.py`
without changing Step 5 code or outputs. The executed read-only validation of
`yolov8n_baseline_full_01` checked 61,319 image records and 274,096 detections
across all 614 committed checkpoints. All 3,124 checks completed in 8.5006 seconds
before report writing: zero critical issues, three dataset-level warnings.
No missing/unexpected images or duplicate keys; all count, class, confidence,
box, reference and checkpoint integrity checks passed. Successful zero images:
10,488; processing failures: zero. No prediction cleaning/correction was necessary.

Warnings retain optional English metadata nulls, known detector limitations and
unverified timezone/clock provenance. Full reports are under
`data/interim/detection_validation/`; see `docs/step6_detection_validation.md`.
All 153 tests passed, including 39 new synthetic validator cases. Ruff was not
installed; no packages were added. No raw pixels were loaded or rehashed, and
no inference, training, Step 7 implementation, commit or push occurred.
Data is structurally ready for Step 7 contract discussion, subject to explicit
timezone/consumer/schema decisions. Model predictions do not establish accuracy,
unique vehicles, traffic flow or congestion.


## Step 7 completed: final engineering handoff (November 17, 2026)

Implemented the evidence-supported **camera-observations-1.0.0** consumer export,
separate from the older unapproved UTC/window proposals. Executed
`scripts/export_datasets.py` against the passed Step 6 full run. New outputs in
`data/processed/`: camera_snapshots.parquet (61,319 rows, 10,862,578 bytes),
vehicle_detections.parquet (274,096 rows, 19,001,830 bytes), camera_metadata.parquet
(100 rows, 15,240 bytes), plus export_manifest.json (4,344 bytes).
All 10,488 successful zero snapshots remain; there are no failed source images,
duplicate keys, orphan references or inconsistent counts. Original class/score/box,
camera and timestamp values are preserved. Camera English nulls remain 1 and 2.

The full export was run twice: both succeeded, and the four published files
remained byte- and mtime-identical on rerun. Full-dataset consumer joins and
schema/checksum gates passed. All 174 tests passed, including 21 new synthetic
export/integration cases. Hash inventories of 1,995 protected prior outputs/input
files were identical before/after. No raw pixels, model inference, dependency
installation, previous pipeline changes, Data Science/Dashboard features, commit
or push were involved.

See docs/step7_data_handoff.md and the implemented contract in the data dictionary
for exact schemas, CLI, join examples, atomic exclusive publication, completion
marker and interrupted/idempotent rerun behavior. Source run ID:
15c14accabe04a87a03b02073ae332e3. Baseline remains YOLOv8n, confidence .25,
imgsz 640, NMS IoU .7, CPU, COCO 2/3/5/7.

Steps 1?7 engineering deliverables are now available locally. Remaining shared
work is consumer handoff/review, Data Science and Dashboard implementation,
external-data provenance, presentation and academic submission. Capture timezone
and camera-clock accuracy remain unverified; no UTC localization was invented.
Known pretrained-model errors and snapshot interpretation limits remain explicit.
Future UTC conversion, window analytics and consumer-specific semantic changes
require evidence/agreement rather than silently changing this contract.
